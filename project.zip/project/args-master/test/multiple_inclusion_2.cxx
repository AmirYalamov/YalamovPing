#include <args.hxx>

int bar() { return 42; }
